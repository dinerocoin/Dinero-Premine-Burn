﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace DineroBurnAddressGen
{
    class Program
    {
        const string alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";   // all allowed base58 characters

        // Entry point of the program
        static void Main(string[] args)
        {
            var Sha256 = SHA256.Create();   // create a new instance of SHA256, the algorithm that will be used to generate hashes later on.
            Console.WriteLine("Please enter a template. e.g. D1N3ro1StHeBest"); // write a line to the console.

            string template = Console.ReadLine(); // grab the user input which will be used to generate an address that will look very similar.

            string originalTemplate = template; // store the old template to be able to check against it later
            template = originalTemplate.Replace('0', 'o').Replace('O', 'o').Replace('l', '1').Replace('I', '1');    // replace all bad characters with good ones
            if (originalTemplate != template)   // check if any characters were replaced
            {
                // write a colored line of text to the console
                WriteToConsoleColored("Warning: Some characters were replaced because they were not contained in the base56 alphabet.\nNew template: " + template, ConsoleColor.Yellow);
            }

            // all addresses need to start with D5
            if (!template.StartsWith("D5")) // if the template doesnt start with D5 then we need to add a D5 prefix
            {
                template = "D5" + template;
            }

            IEnumerable<char> invChars = template.Where(x => !alphabet.Contains(x)).Distinct();    // get invalid characters, like + or /
            if (invChars.Any()) // if there are any invalid characters show them in the console
            {
                // write a red message to the console showing the invalid characters (string.join joins the invalid characters together) (.Select would turn the character a into 'a')
                WriteToConsoleColored("Error: Invalid character(s): " + string.Join(null, invChars.Select(x=>$"'{x}'")), ConsoleColor.Red); 

                Console.ReadLine(); // only close after pressing ENTER
                return; // exit the program
            }

            if (template.Count() > 34)  // if the template is too long
            {
                template = template.Substring(0, 34); // remove all characters after 34th
            }
            if (template.Count() < 34)  // if the template is too short
            {
                template += new string('X', 34 - template.Count()); // add Xes onto it so the length is equal to 34
            }
            /*  What does an address look like?
             *  D5<26 characters that may be chosen><Checksum(6 characters)>
             *  D5 is a prefix that has to always be there
             *  after that there are 26 characters that can be chosen freely
             *  the last 6 characters are responsible for the checksum and will be generated automatically
             */

            var allBytes = Base58Decode(template);  // convert the template to bytes
            var nonCheckSumBytes = allBytes.Reverse().Skip(4).Reverse().ToArray();  // remove the bytes that display the checksum
            var checksum = Sha256.ComputeHash(Sha256.ComputeHash(nonCheckSumBytes));    // hash the bytes that arent responsible for the checksum twice
            var bytes = new byte[25];   // create a new variable to store the bytes from our template and the checksum (<template-bytes><checksum-bytes>)
            nonCheckSumBytes.CopyTo(bytes, 0);  // add the template-bytes
            checksum.Take(4).ToArray().CopyTo(bytes, 21);   // add the checksum-bytes
            var address = Base58Encode(bytes);  // re-encode the address
            Console.WriteLine("Here is your address: " + address);  // write the address to the console
            Console.ReadLine(); // only close after pressing ENTER
        }

        /// <summary>
        /// Method for writing colored text to the console.
        /// </summary>
        /// <param name="message">The message to be written.</param>
        /// <param name="newColor">The color to use for the text.</param>
        public static void WriteToConsoleColored(string message, ConsoleColor newColor)
        {
            var origColor = Console.ForegroundColor;    // save the current color
            Console.ForegroundColor = newColor;         // set the new text color
            Console.WriteLine(message);                 // write the message
            Console.ForegroundColor = origColor;        // reset the console color
        }

        /// <summary>
        /// Method for encoding bytes to base58
        /// </summary>
        /// <param name="bytes">The byte array to be encoded</param>
        /// <returns>A base58 string representing the byte array</returns>
        public static string Base58Encode(byte[] bytes)
        {

            var alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
            var bi = new BigInteger(bytes.Reverse().ToArray());
            string ret = "";
            while (bi >= 58)
            {
                var mod = bi % 58;
                ret = (alphabet[(int)mod]) + ret;
                bi = (bi - mod) / 58;
            }
            ret = alphabet[(int)bi] + ret;

            for (int i = 0; i < bytes.Length; i++)
            {
                if (bytes[i] == 0)
                {
                    ret = alphabet[0] + ret;
                }
                else
                {
                    break;
                }
            }
            return ret;
        }

        /// <summary>
        /// Method for decoding base58 to bytes
        /// </summary>
        /// <param name="input">The base58 string to be decoded</param>
        /// <returns>A byte array representing the given base58 input string</returns>
        public static byte[] Base58Decode(string input)
        {
            var alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
            var bi = new BigInteger(0);
            var leadingZeroes = 0;
            for (int i = input.Length - 1; i >= 0; i--)
            {
                var alphabetIndex = alphabet.IndexOf(input[i]);
                if (alphabetIndex < 0)
                {
                    throw new ArgumentException("Invalid character");
                }
                bi += new BigInteger(alphabetIndex) * BigInteger.Pow(58, input.Length - 1 - i);
                if (input[i] == '1')
                    leadingZeroes++;
                else
                    leadingZeroes = 0;
            }
            List<byte> bytes = bi.ToByteArray().ToList();
            while (leadingZeroes-- > 0)
                bytes.Insert(0, (byte)0);

            return bytes.ToArray().Reverse().ToArray();
        }
    }
}
